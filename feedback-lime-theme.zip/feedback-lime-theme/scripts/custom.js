$(function () {
    function receiver(event) {
        //Autorização do domínio do site em que está instalado o widget
     if (event.origin !== "http://127.0.0.1:5500"){
         alert("Sem permissão")
     }else{
         //ID da pergunta oculta
         $("#answer265758X391X2281").val(event.data)
     }
    }
    
    window.addEventListener('message', receiver, false);
})

